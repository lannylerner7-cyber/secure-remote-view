using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

namespace ConnectLive.Agent;

/// <summary>
/// Desktop capture loop. Runs at ~7fps (140ms) and cheaply skips upload
/// when the screen hasn't visibly changed (fast strided FNV-1a hash on the
/// scaled RGB buffer). Downsamples to max 1280px long edge, JPEG q55.
/// </summary>
public static class ScreenCapture
{
    private const uint CURSOR_SHOWING = 0x00000001;
    private const int DI_NORMAL = 0x0003;

    public static async Task RunAsync(ApiClient api, string sessionId, CancellationToken ct)
    {
        var encoders = ImageCodecInfo.GetImageEncoders();
        ImageCodecInfo? jpegEnc = null;
        foreach (var e in encoders) if (e.MimeType == "image/jpeg") { jpegEnc = e; break; }
        if (jpegEnc == null) return;

        var encParams = new EncoderParameters(1);
        encParams.Param[0] = new EncoderParameter(Encoder.Quality, 55L);

        ulong lastHash = 0;
        int idleCount = 0;

        while (!ct.IsCancellationRequested)
        {
            try
            {
                var bounds = System.Windows.Forms.Screen.PrimaryScreen?.Bounds
                             ?? new Rectangle(0, 0, 1920, 1080);
                ulong cursorKey = 0;
                using var raw = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format32bppArgb);
                using (var g = Graphics.FromImage(raw))
                {
                    g.CopyFromScreen(bounds.Location, Point.Empty, bounds.Size);
                    DrawCursor(g, bounds, out cursorKey);
                }

                int maxEdge = 1280;
                double scale = Math.Min(1.0, (double)maxEdge / Math.Max(raw.Width, raw.Height));
                int w = Math.Max(1, (int)(raw.Width * scale));
                int h = Math.Max(1, (int)(raw.Height * scale));

                using var scaled = new Bitmap(w, h, PixelFormat.Format32bppArgb);
                using (var g = Graphics.FromImage(scaled))
                {
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.Bilinear;
                    g.DrawImage(raw, 0, 0, w, h);
                }

                // Fast dirty-frame detection: FNV-1a over strided pixel samples.
                ulong hash = HashBitmap(scaled) ^ cursorKey;
                bool unchanged = hash == lastHash;
                // Force a keyframe every ~2s even when idle, so a fresh admin
                // subscriber still sees the current screen.
                if (unchanged && idleCount < 12) { idleCount++; }
                else
                {
                    idleCount = 0;
                    lastHash = hash;
                    using var ms = new MemoryStream();
                    scaled.Save(ms, jpegEnc, encParams);
                    await api.PostFrameAsync(sessionId, ms.ToArray(), w, h, ct);
                }
            }
            catch (Exception ex)
            {
                Log.Warn($"capture: {ex.Message}");
            }

            try { await Task.Delay(140, ct); } catch { }
        }
    }

    private static ulong HashBitmap(Bitmap bmp)
    {
        var rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        var data = bmp.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        try
        {
            int total = data.Stride * bmp.Height;
            int step = Math.Max(64, total / 4096); // ~4k samples
            ulong hash = 1469598103934665603UL; // FNV-1a offset
            IntPtr ptr = data.Scan0;
            var buf = new byte[Math.Min(total, 8)];
            for (int i = 0; i < total; i += step)
            {
                Marshal.Copy(IntPtr.Add(ptr, i), buf, 0, buf.Length);
                for (int k = 0; k < buf.Length; k++)
                {
                    hash ^= buf[k];
                    hash *= 1099511628211UL;
                }
            }
            return hash;
        }
        finally { bmp.UnlockBits(data); }
    }

    private static void DrawCursor(Graphics g, Rectangle screenBounds, out ulong cursorKey)
    {
        cursorKey = 0;
        try
        {
            var info = new CURSORINFO { cbSize = Marshal.SizeOf<CURSORINFO>() };
            if (!GetCursorInfo(ref info) || (info.flags & CURSOR_SHOWING) == 0 || info.hCursor == IntPtr.Zero) return;

            int hotX = 0;
            int hotY = 0;
            if (GetIconInfo(info.hCursor, out var iconInfo))
            {
                hotX = iconInfo.xHotspot;
                hotY = iconInfo.yHotspot;
                if (iconInfo.hbmMask != IntPtr.Zero) DeleteObject(iconInfo.hbmMask);
                if (iconInfo.hbmColor != IntPtr.Zero) DeleteObject(iconInfo.hbmColor);
            }

            int x = info.ptScreenPos.X - screenBounds.Left - hotX;
            int y = info.ptScreenPos.Y - screenBounds.Top - hotY;
            cursorKey = ((ulong)(uint)info.ptScreenPos.X << 32) ^ (uint)info.ptScreenPos.Y ^ (ulong)info.hCursor.ToInt64();

            // CopyFromScreen does not include the hardware cursor, so paint it
            // into the frame before scaling. This makes the admin's shared view
            // show the real pointer position, including during remote control.
            var hdc = g.GetHdc();
            try { DrawIconEx(hdc, x, y, info.hCursor, 0, 0, 0, IntPtr.Zero, DI_NORMAL); }
            finally { g.ReleaseHdc(hdc); }
        }
        catch
        {
            // Cursor rendering should never break screen streaming.
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct POINT
    {
        public int X;
        public int Y;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct CURSORINFO
    {
        public int cbSize;
        public uint flags;
        public IntPtr hCursor;
        public POINT ptScreenPos;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct ICONINFO
    {
        public bool fIcon;
        public int xHotspot;
        public int yHotspot;
        public IntPtr hbmMask;
        public IntPtr hbmColor;
    }

    [DllImport("user32.dll")]
    private static extern bool GetCursorInfo(ref CURSORINFO pci);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool DrawIconEx(IntPtr hdc, int xLeft, int yTop, IntPtr hIcon, int cxWidth, int cyWidth, int istepIfAniCur, IntPtr hbrFlickerFreeDraw, int diFlags);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool GetIconInfo(IntPtr hIcon, out ICONINFO piconinfo);

    [DllImport("gdi32.dll", SetLastError = true)]
    private static extern bool DeleteObject(IntPtr hObject);
}
